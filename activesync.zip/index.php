<?
chdir(__DIR__);

include_once("active_sync_kern.php");

active_sync_http();
?>
